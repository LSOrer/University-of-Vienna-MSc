package iop_artifact;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Month;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

public class iop_insert_order {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		String url = "jdbc:postgresql://localhost:5432/postgres";
		Properties props = new Properties();
		props.setProperty("user", "postgres");
		props.setProperty("password", "");
		try {
			Connection conn = DriverManager.getConnection(url, props);
			Statement stmt = conn.createStatement();
			createOrderData(conn, stmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void createOrderData(Connection c, Statement stmt) {
		String[] itname = { "Water", "Cola", "Fanta", "Sprite", "Burgerbun", "Patty", "+ lettuce", "+ tomato",
				"+ onion", "+ mushroom", "+ cucumber", "+ cheese", "+ pickle", "+ bacon", "+ ketchup", "+ mustard",
				"+ ranch", "Fries", "Wedges", "+ mayo" };
		try {
			for (int i = 1; i < 778; i++) {

				int customerid = ThreadLocalRandom.current().nextInt(1, 777);
				int itemid = ThreadLocalRandom.current().nextInt(1, 777);
				int robotid = ThreadLocalRandom.current().nextInt(1, 777);
				int[] addloyalty = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
				String i2 = String.valueOf(i);
				double total = ThreadLocalRandom.current().nextDouble(1.5, 80.0);
				double total2 = Math.round(total * 100.0) / 100.0;
				String total3 = String.valueOf(total2);

				// https://stackoverflow.com/questions/23520208/how-to-create-xml-file-with-specific-structure-in-java
				Element root = new Element("Orderdetails");
				Document doc = new Document();
				Element child1 = new Element("OrderID");
				child1.addContent(i2);
				Element child2 = new Element("OrderItems");
				child2.addContent(
						new Element("Item1").addContent(itname[ThreadLocalRandom.current().nextInt(0, itname.length)]));
				child2.addContent(
						new Element("Item2").addContent(itname[ThreadLocalRandom.current().nextInt(0, itname.length)]));
				child2.addContent(
						new Element("Item3").addContent(itname[ThreadLocalRandom.current().nextInt(0, itname.length)]));

				Element child3 = new Element("Total");

				child3.addContent(total3);

				root.addContent(child1);
				root.addContent(child2);
				root.addContent(child3);

				doc.setRootElement(root);

				XMLOutputter outter = new XMLOutputter();
				outter.setFormat(Format.getPrettyFormat());

				String insertSql = "INSERT INTO public.\"Order\" VALUES (" + i + ", " + customerid + ", " + itemid
						+ ", " + robotid + ", '" + randomDate() + "', "
						+ addloyalty[ThreadLocalRandom.current().nextInt(0, addloyalty.length)] + ", '"
						+ outter.outputString(root) + "')";

				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// https://www.baeldung.com/java-random-dates
	private static Date randomDate() {
		LocalDate start = LocalDate.of(2020, Month.JANUARY, 01);
		LocalDate end = LocalDate.now();
		return Date.valueOf(between(start, end));
	}

	private static LocalDate between(LocalDate startInclusive, LocalDate endExclusive) {
		long startEpochDay = startInclusive.toEpochDay();
		long endEpochDay = endExclusive.toEpochDay();
		long randomDay = ThreadLocalRandom.current().nextLong(startEpochDay, endEpochDay);

		return LocalDate.ofEpochDay(randomDay);
	}
}
