package iop_artifact;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

public class iop_insert_orderitem {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		String url = "jdbc:postgresql://localhost:5432/postgres";
		Properties props = new Properties();
		props.setProperty("user", "postgres");
		props.setProperty("password", "");
		try {
			Connection conn = DriverManager.getConnection(url, props);
			Statement stmt = conn.createStatement();
			createCustomerData(conn, stmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void createCustomerData(Connection c, Statement stmt) {
		String[] itname = { "Water", "Cola", "Fanta", "Sprite", "Burgerbun", "Patty", "+ lettuce", "+ tomato",
				"+ onion", "+ mushroom", "+ cucumber", "+ cheese", "+ pickle", "+ bacon", "+ ketchup", "+ mustard",
				"+ ranch", "Fries", "Wedges", "+ mayo" };

		char[] itsize = { 's', 'm', 'l' };

		try {
			for (int i = 1; i < 778; i++) {

				int ingredientid = ThreadLocalRandom.current().nextInt(1, 777);
				int orderid = ThreadLocalRandom.current().nextInt(1, 777);
				double itcost = 0.01;
				int ithealth = 1;

				String insertSql = "INSERT INTO public.\"OrderItem\" VALUES (" + i + ", " + ingredientid + ", '"
						+ itname[ThreadLocalRandom.current().nextInt(0, itname.length)] + "', '"
						+ itsize[ThreadLocalRandom.current().nextInt(0, itsize.length)] + "', " + itcost + ", "
						+ ithealth + ", " + orderid + ")";

				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

/**
 * After insertion had to update the table manually:
 * 
 * UPDATE public."OrderItem" SET itcost=1 WHERE itname='Water' AND itsize='s';
 * 
 * UPDATE public."OrderItem" SET itcost=2 WHERE itname='Water' AND itsize='m';
 * 
 * UPDATE public."OrderItem" SET itcost=3 WHERE itname='Water' AND itsize='l';
 * 
 * UPDATE public."OrderItem" SET ithealthf=2 WHERE itname='+ mayo';
 * 
 * AND SO FORTH...
 * 
 */
