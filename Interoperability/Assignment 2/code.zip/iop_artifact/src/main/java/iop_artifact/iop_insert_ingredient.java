package iop_artifact;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

public class iop_insert_ingredient {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		String url = "jdbc:postgresql://localhost:5432/postgres";
		Properties props = new Properties();
		props.setProperty("user", "postgres");
		props.setProperty("password", "");
		try {
			Connection conn = DriverManager.getConnection(url, props);
			Statement stmt = conn.createStatement();
			createCustomerData(conn, stmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void createCustomerData(Connection c, Statement stmt) {

		String[] inname = { "Water", "Cola syrup", "Fanta syrup", "Sprite syrup", "Burgerbun", "Ground meat", "Lettuce",
				"Tomato", "Onion", "Mushroom", "Cucumber", "Cheese", "Pickle", "Bacon", "Ketchup", "Mustard", "Ranch",
				"Potato", "Mayo" };
		String intype = "NULL";
		String inalergic = "NULL";

		try {
			for (int i = 1; i < 778; i++) {
				int itemid = ThreadLocalRandom.current().nextInt(0, 777);
				int stockid = ThreadLocalRandom.current().nextInt(0, 777);
				String insertSql = "INSERT INTO public.\"Ingredient\" VALUES (" + i + ", " + itemid + ", '" + stockid
						+ "', '" + inname[ThreadLocalRandom.current().nextInt(0, inname.length)] + "', " + inalergic
						+ ", " + intype + ")";
				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

/**
 * After insertion had to update the table manually:
 * 
 * UPDATE public."Ingredient" SET inalergic='A, C, G' WHERE inname='Burgerbun';
 * 
 * UPDATE public."Ingredient" SET inalergic='G' WHERE inname='Cheese';
 * 
 * UPDATE public."Ingredient" SET inalergic='M' WHERE inname='Mustard';
 * 
 * UPDATE public."Ingredient" SET inalergic='C, G' WHERE inname='Ranch';
 * 
 * UPDATE public."Ingredient" SET inalergic='C, G' WHERE inname='Mayo';
 * 
 * UPDATE public."Ingredient" SET intype='Drink' WHERE inname='Water' OR
 * inname='Cola syrup' OR inname='Fanta syrup' OR inname='Sprite syrup';
 * 
 * UPDATE public."Ingredient" SET intype='Burger' WHERE inname='Burgerbun' OR
 * inname='Ground meat' OR inname='Lettuce' OR inname='Tomato' OR inname='Onion'
 * OR inname='Mushroom' OR inname='Cucumber' OR inname='Cheese' OR
 * inname='Pickle' OR inname='Bacon' OR inname='Ketchup' OR inname='Mustard' OR
 * inname='Ranch' OR inname='Mayo';
 * 
 * UPDATE public."Ingredient" SET intype='Side dish' WHERE inname='Potato';
 * 
 */
