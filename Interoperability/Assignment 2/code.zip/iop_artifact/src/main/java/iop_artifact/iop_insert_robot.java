package iop_artifact;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

public class iop_insert_robot {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		String url = "jdbc:postgresql://localhost:5432/postgres";
		Properties props = new Properties();
		props.setProperty("user", "postgres");
		props.setProperty("password", "");
		try {
			Connection conn = DriverManager.getConnection(url, props);
			Statement stmt = conn.createStatement();
			createOrderData(conn, stmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void createOrderData(Connection c, Statement stmt) {

		try {
			for (int i = 1; i < 200; i++) {

				String[] rname = { "Joe", "Sandra", "Barney", "Alice", "Bob" };
				String[] rtype = { "interaction_manager", "stock_manager", "burger_chef", "drink_mixer",
						"fries_expert" };
				String[] rfunction = { "customer communication", "ordering", "produce burger", "produce baverage",
						"produce fries" };

				int deliveryid = ThreadLocalRandom.current().nextInt(0, 777);
				int orderid = ThreadLocalRandom.current().nextInt(0, 777);

				String insertSql = "INSERT INTO public.\"Robot\" VALUES (" + i + ", '" + rname[0] + "', '" + rtype[0]
						+ "', '" + rfunction[0] + "', " + deliveryid + ", " + orderid + ")";

				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}
			for (int i = 200; i < 400; i++) {

				String[] rname = { "Joe", "Sandra", "Barney", "Alice", "Bob" };
				String[] rtype = { "interaction_manager", "stock_manager", "burger_chef", "drink_mixer",
						"fries_expert" };
				String[] rfunction = { "customer communication", "ordering", "produce burger", "produce baverage",
						"produce fries" };

				int deliveryid = ThreadLocalRandom.current().nextInt(0, 777);
				int orderid = ThreadLocalRandom.current().nextInt(0, 777);

				String insertSql = "INSERT INTO public.\"Robot\" VALUES (" + i + ", '" + rname[1] + "', '" + rtype[1]
						+ "', '" + rfunction[1] + "', " + deliveryid + ", " + orderid + ")";

				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}
			for (int i = 400; i < 500; i++) {

				String[] rname = { "Joe", "Sandra", "Barney", "Alice", "Bob" };
				String[] rtype = { "interaction_manager", "stock_manager", "burger_chef", "drink_mixer",
						"fries_expert" };
				String[] rfunction = { "customer communication", "ordering", "produce burger", "produce baverage",
						"produce fries" };

				int deliveryid = ThreadLocalRandom.current().nextInt(0, 777);
				int orderid = ThreadLocalRandom.current().nextInt(0, 777);

				String insertSql = "INSERT INTO public.\"Robot\" VALUES (" + i + ", '" + rname[2] + "', '" + rtype[2]
						+ "', '" + rfunction[2] + "', " + deliveryid + ", " + orderid + ")";

				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}
			for (int i = 500; i < 600; i++) {

				String[] rname = { "Joe", "Sandra", "Barney", "Alice", "Bob" };
				String[] rtype = { "interaction_manager", "stock_manager", "burger_chef", "drink_mixer",
						"fries_expert" };
				String[] rfunction = { "customer communication", "ordering", "produce burger", "produce baverage",
						"produce fries" };

				int deliveryid = ThreadLocalRandom.current().nextInt(0, 777);
				int orderid = ThreadLocalRandom.current().nextInt(0, 777);

				String insertSql = "INSERT INTO public.\"Robot\" VALUES (" + i + ", '" + rname[3] + "', '" + rtype[3]
						+ "', '" + rfunction[3] + "', " + deliveryid + ", " + orderid + ")";

				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}
			for (int i = 600; i < 778; i++) {

				String[] rname = { "Joe", "Sandra", "Barney", "Alice", "Bob" };
				String[] rtype = { "interaction_manager", "stock_manager", "burger_chef", "drink_mixer",
						"fries_expert" };
				String[] rfunction = { "customer communication", "ordering", "produce burger", "produce baverage",
						"produce fries" };

				int deliveryid = ThreadLocalRandom.current().nextInt(0, 777);
				int orderid = ThreadLocalRandom.current().nextInt(0, 777);

				String insertSql = "INSERT INTO public.\"Robot\" VALUES (" + i + ", '" + rname[4] + "', '" + rtype[4]
						+ "', '" + rfunction[4] + "', " + deliveryid + ", " + orderid + ")";

				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
