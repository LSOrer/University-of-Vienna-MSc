package iop_artifact;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Month;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

public class iop_inser_delivery {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		String url = "jdbc:postgresql://localhost:5432/postgres";
		Properties props = new Properties();
		props.setProperty("user", "postgres");
		props.setProperty("password", "");
		try {
			Connection conn = DriverManager.getConnection(url, props);
			Statement stmt = conn.createStatement();
			createCustomerData(conn, stmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void createCustomerData(Connection c, Statement stmt) {

		String[] vendor = { "Cocacola Comp.", "FreshMarket", "ButcherMoe", "Metro", "PackingKing", "Billa", "Spar",
				"Merkur", "Denns" };

		try {
			for (int i = 1; i < 778; i++) {

				int stockid = ThreadLocalRandom.current().nextInt(0, 777);
				int robotid = ThreadLocalRandom.current().nextInt(0, 777);
				int damount = ThreadLocalRandom.current().nextInt(1, 20);

				double dcost = ThreadLocalRandom.current().nextDouble(20.0, 400.0);
				double dcost2 = Math.round(dcost * 100.0) / 100.0;

				String insertSql = "INSERT INTO public.\"Delivery\" VALUES (" + i + ", " + stockid + ", '"
						+ randomDate() + "', '" + vendor[ThreadLocalRandom.current().nextInt(0, vendor.length)] + "', "
						+ damount + ", " + dcost2 + ", " + robotid + ")";

				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// https://www.baeldung.com/java-random-dates
	private static Date randomDate() {
		LocalDate start = LocalDate.of(2020, Month.JANUARY, 01);
		LocalDate end = LocalDate.now();
		return Date.valueOf(between(start, end));
	}

	private static LocalDate between(LocalDate startInclusive, LocalDate endExclusive) {
		long startEpochDay = startInclusive.toEpochDay();
		long endEpochDay = endExclusive.toEpochDay();
		long randomDay = ThreadLocalRandom.current().nextLong(startEpochDay, endEpochDay);

		return LocalDate.ofEpochDay(randomDay);
	}

}
