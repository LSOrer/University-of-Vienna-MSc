package iop_artifact;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Month;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.RandomStringUtils;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

public class iop_insert_customer {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		String url = "jdbc:postgresql://localhost:5432/postgres";
		Properties props = new Properties();
		props.setProperty("user", "postgres");
		props.setProperty("password", "");
		try {
			Connection conn = DriverManager.getConnection(url, props);
			Statement stmt = conn.createStatement();
			createCustomerData(conn, stmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void createCustomerData(Connection c, Statement stmt) {
		String[] city = { "Berlin", "Munich", "Graz", "Salzburg", "St.Poelten", "Linz", "Wien", "Bregenz", "Eisenstadt",
				"Klagenfurt" };
		int[] loyaltypoints = { 1, 20, 5, 51, 72, 3, 78, 88, 19, 60, 20, 45, 11, 9, 70, 34, 10 };
		try {
			for (int i = 1; i < 778; i++) {
				String fname = RandomStringUtils.randomAlphabetic(8);
				String lname = RandomStringUtils.randomAlphabetic(8);
				// https://stackoverflow.com/questions/23520208/how-to-create-xml-file-with-specific-structure-in-jav
				Element root = new Element("Address");
				Document doc = new Document();
				Element child1 = new Element("City");
				child1.addContent(city[ThreadLocalRandom.current().nextInt(0, city.length)]);
				Element child2 = new Element("Country");
				child2.addContent("Austria");
				String sname = RandomStringUtils.randomAlphabetic(8);
				int snumber = ThreadLocalRandom.current().nextInt(1, 120);
				String snumber2 = String.valueOf(snumber);
				int sadd = ThreadLocalRandom.current().nextInt(1, 30);
				String sadd2 = String.valueOf(sadd);
				Element child3 = new Element("Street");
				child3.addContent(new Element("Street").addContent(sname + "-street"));
				child3.addContent(new Element("Number").addContent(snumber2));
				child3.addContent(new Element("Additional").addContent(sadd2));

				root.addContent(child1);
				root.addContent(child2);
				root.addContent(child3);

				doc.setRootElement(root);
				XMLOutputter outter = new XMLOutputter();
				outter.setFormat(Format.getPrettyFormat());

				String insertSql = "INSERT INTO public.\"Customer\" VALUES ('" + lname + "', '" + fname + "', " + i
						+ ", '" + randomDate() + "', '"
						+ loyaltypoints[ThreadLocalRandom.current().nextInt(0, loyaltypoints.length)] + "', '"
						+ outter.outputString(root) + "')";

				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// https://www.baeldung.com/java-random-dates
	private static Date randomDate() {
		LocalDate start = LocalDate.of(1980, Month.JANUARY, 01);
		LocalDate end = LocalDate.of(2000, Month.DECEMBER, 31);
		return Date.valueOf(between(start, end));
	}

	private static LocalDate between(LocalDate startInclusive, LocalDate endExclusive) {
		long startEpochDay = startInclusive.toEpochDay();
		long endEpochDay = endExclusive.toEpochDay();
		long randomDay = ThreadLocalRandom.current().nextLong(startEpochDay, endEpochDay);

		return LocalDate.ofEpochDay(randomDay);
	}

}
