package iop_artifact;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

public class iop_insert_xml {
	public static void main(String[] args) {

// https://stackoverflow.com/questions/23520208/how-to-create-xml-file-with-specific-structure-in-java		

		// Root Element
		Element root = new Element("Orderdetails");
		Document doc = new Document();
		// Element 1
		Element child1 = new Element("OrderID");
		// Element 1 Content
		child1.addContent("chrome");
		// Element 2
		Element child2 = new Element("BASE");
		// Element 2 Content
		child2.addContent("http:fut");
		// Element 3
		Element child3 = new Element("EMPLOYEE");
		// Element 3 --> In this case this element has another element with Content
		child3.addContent(new Element("EMP_NAME").addContent("Anhorn, Irene"));

		// Add it in the root Element
		root.addContent(child1);
		root.addContent(child2);
		root.addContent(child3);
		// Define root element like root
		doc.setRootElement(root);
		// Create the XML
		XMLOutputter outter = new XMLOutputter();
		outter.setFormat(Format.getPrettyFormat());

		System.out.println(outter.outputString(root));

	}
}