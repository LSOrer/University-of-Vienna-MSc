package iop_artifact;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.RandomStringUtils;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

public class iop_insert {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		String url = "jdbc:postgresql://localhost:5432/postgres";
		Properties props = new Properties();
		props.setProperty("user", "postgres");
		props.setProperty("password", "");
		try {
			Connection conn = DriverManager.getConnection(url, props);
			Statement stmt = conn.createStatement();
			createAccountData(conn, stmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void createAccountData(Connection c, Statement stmt) {

		String[] city = { "Graz", "Salzburg", "St.Poelten", "Linz", "Wien", "Bregenz", "Eisenstadt", "Klagenfurt" };

		try {
			for (int i = 1; i < 778; i++) {
				// https://stackoverflow.com/questions/23520208/how-to-create-xml-file-with-specific-structure-in-java
				Element root = new Element("Address");
				Document doc = new Document();
				Element child1 = new Element("City");
				child1.addContent(city[ThreadLocalRandom.current().nextInt(0, city.length)]);
				Element child2 = new Element("Country");
				child2.addContent("Austria");
				String sname = RandomStringUtils.randomAlphabetic(8);
				int snumber = ThreadLocalRandom.current().nextInt(1, 120);
				String snumber2 = String.valueOf(snumber);
				int sadd = ThreadLocalRandom.current().nextInt(1, 30);
				String sadd2 = String.valueOf(sadd);
				Element child3 = new Element("Street");
				child3.addContent(new Element("Street").addContent(sname + "-street"));
				child3.addContent(new Element("Number").addContent(snumber2));
				child3.addContent(new Element("Additional").addContent(sadd2));

				root.addContent(child1);
				root.addContent(child2);
				root.addContent(child3);

				doc.setRootElement(root);
				XMLOutputter outter = new XMLOutputter();
				outter.setFormat(Format.getPrettyFormat());

				// System.out.println(outter.outputString(root));

				String insertSql = "INSERT INTO public.\"Customer\" VALUES ('" + outter.outputString(root) + "')";

				System.out.println(insertSql);
				// stmt.executeUpdate(insertSql);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
