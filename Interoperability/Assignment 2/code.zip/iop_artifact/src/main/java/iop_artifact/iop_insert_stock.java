package iop_artifact;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

public class iop_insert_stock {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		String url = "jdbc:postgresql://localhost:5432/postgres";
		Properties props = new Properties();
		props.setProperty("user", "postgres");
		props.setProperty("password", "");
		try {
			Connection conn = DriverManager.getConnection(url, props);
			Statement stmt = conn.createStatement();
			createCustomerData(conn, stmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void createCustomerData(Connection c, Statement stmt) {

		try {
			for (int i = 1; i < 778; i++) {
				int ingredientid = ThreadLocalRandom.current().nextInt(0, 777);
				int scurrent = ThreadLocalRandom.current().nextInt(0, 50);
				int snew = ThreadLocalRandom.current().nextInt(0, 50);
				int[] smaxcapa = { 2, 5, 10, 20, 30, 40, 50 };
				int deliveryid = ThreadLocalRandom.current().nextInt(0, 777);

				String insertSql = "INSERT INTO public.\"Stock\" VALUES (" + i + ", " + ingredientid + ", " + scurrent
						+ ", " + snew + ", " + smaxcapa[ThreadLocalRandom.current().nextInt(0, smaxcapa.length)] + ", "
						+ deliveryid + ")";

				// System.out.println(insertSql);
				stmt.executeUpdate(insertSql);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
